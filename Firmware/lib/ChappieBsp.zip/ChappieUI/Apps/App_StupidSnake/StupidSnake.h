/**
 * @file StupidSnake.h
 * @author Forairaaaaa
 * @brief 
 * @version 0.1
 * @date 2023-03-21
 * 
 * @copyright Copyright (c) 2023
 * 
 */
#pragma once
#include "../../../ChappieBsp/Chappie.h"

void Game_Setup(CHAPPIE* device);
void Game_Loop();
void Game_End();
