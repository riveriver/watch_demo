/**
 * @file lvgl.h
 * @author Forairaaaaa
 * @brief Fake lvgl.h to cheat demos 
 * @version 0.1
 * @date 2023-03-11
 * 
 * @copyright Copyright (c) 2023
 * 
 */
#pragma once
#include <lvgl.h>
